package com.example.app

data class Forecastitem(var date:String, var time:String,var weather:String,var temp:Int)
